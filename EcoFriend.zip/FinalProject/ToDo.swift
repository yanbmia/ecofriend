//
//  ToDo.swift
//  FinalProject
//
//  Created by Darby Lee-Stack on 7/30/20.
//  Copyright © 2020 Mia Yan. All rights reserved.
//

import UIKit

class ToDoClass {
    
    var description = ""
    var important = false

}
