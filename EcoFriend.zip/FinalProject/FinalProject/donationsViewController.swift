//
//  donationsViewController.swift
//  FinalProject
//
//  Created by Mia Yan on 7/31/20.
//  Copyright © 2020 Mia Yan. All rights reserved.
//

import UIKit

class donationsViewController: UIViewController {

    
    @IBOutlet weak var textView: UITextView!
    
    @IBOutlet weak var textView2: UITextView!
    
    @IBOutlet weak var textView3: UITextView!
    
    @IBOutlet weak var textView4: UITextView!
    
    @IBOutlet weak var textView5: UITextView!
    
    @IBOutlet weak var textView6: UITextView!
    
    @IBOutlet weak var textView7: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateTextView()
        updateTextView2()
        updateTextView3()
    }
         
         func updateTextView() {
             let path = "https://www.rainforestcoalition.org/"
             let text = textView.text ?? ""
             let attributedString = NSAttributedString.makeHyperlink(for: path, in: text, as: "Coalition for Rainforest Nations")
             let font = textView.font
             textView.attributedText = attributedString
             textView.font = font
         }
        
         func updateTextView2() {
             let path = "https://www.catf.us/"
             let text = textView2.text ?? ""
             let attributedString = NSAttributedString.makeHyperlink(for: path, in: text, as: "Clean Air Task Force")
             let font = textView2.font
             textView2.attributedText = attributedString
             textView2.font = font
         }
         
         func updateTextView3() {
             let path = "https://rainforestfoundation.org/"
             let text = textView3.text ?? ""
             let attributedString = NSAttributedString.makeHyperlink(for: path, in: text, as: "Rainforest Foundation US")
             let font = textView3.font
             textView3.attributedText = attributedString
             textView3.font = font
         }
         
         
}
